const cells = document.querySelectorAll('.cell');
const statusDiv = document.getElementById('status');
const scoreXSpan = document.getElementById('scoreX');
const scoreOSpan = document.getElementById('scoreO');
const scoreDrawSpan = document.getElementById('scoreDraw');
const drawMessage = document.getElementById('drawMessage');
const startMessage = document.getElementById('startMessage');
const startGameButton = document.getElementById('startGameButton');
const board = document.querySelector('.board');
const scoreboard = document.getElementById('scoreboard');
const endGameButton = document.getElementById('endGameButton');

let currentPlayer = 'X';
let gameBoard = ['', '', '', '', '', '', '', '', '']; // Boş oyun tahtası
let gameActive = false;

let scoreX = 0;
let scoreO = 0;
let scoreDraw = 0; // Beraberlik sayacı

const winningCombinations = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6]
];

// Oyun durumunu güncelle
function updateGameStatus(message) {
    statusDiv.textContent = message;
}

// Skoru güncelle
function updateScore() {
    scoreXSpan.textContent = scoreX;
    scoreOSpan.textContent = scoreO;
    scoreDrawSpan.textContent = scoreDraw; // Beraberlik skorunu da güncelle
}

// Beraberlik mesajını gizle veya göster
function toggleDrawMessage(show) {
    if (show) {
        drawMessage.style.display = 'block';
    } else {
        drawMessage.style.display = 'none';
    }
}

// Hücreye tıklama olayı
function cellClick(event) {
    const index = event.target.getAttribute('data-index');
    
    if (gameBoard[index] !== '' || !gameActive) return; // Hücre zaten doluysa veya oyun bitmişse işlem yapma

    // Hücreyi işaretle
    gameBoard[index] = currentPlayer;
    event.target.textContent = currentPlayer;

    // X'in rengi kırmızı, O'nun rengi mavi olmalı
    if (currentPlayer === 'X') {
        event.target.classList.add('x');
    } else {
        event.target.classList.add('o');
    }

    // Kazananı kontrol et
    if (checkWinner()) {
        updateGameStatus(`${currentPlayer} Kazandı!`);
        if (currentPlayer === 'X') {
            scoreX++;
        } else {
            scoreO++;
        }
        updateScore();  // Skoru güncelle
        gameActive = false;
        
        // Oyun bitiminde 1 saniye sonra otomatik sıfırlama
        setTimeout(resetGame, 1500); // 1.5 saniye sonra sıfırlanır
        return;
    }

    // Beraberlik kontrolü
    if (!gameBoard.includes('')) {
        updateGameStatus('Beraberlik!');
        toggleDrawMessage(true);  // Beraberlik mesajını göster
        scoreDraw++; // Beraberlik skoru artıyor
        updateScore();  // Beraberlik skorunu güncelle
        gameActive = false;
        
        // Oyun bitiminde 1 saniye sonra otomatik sıfırlama
        setTimeout(resetGame, 1500); // 1.5 saniye sonra sıfırlanır
        return;
    }

    // Sıradaki oyuncuya geç
    currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
    updateGameStatus(`${currentPlayer}'in Sırası`); // Artık "Sıra X'de" gibi bir mesaj yok
}

// Kazanan kontrolü
function checkWinner() {
    for (let combination of winningCombinations) {
        const [a, b, c] = combination;
        if (gameBoard[a] && gameBoard[a] === gameBoard[b] && gameBoard[a] === gameBoard[c]) {
            return true;
        }
    }
    return false;
}

// Oyun tahtasını sıfırla
function resetGame() {
    gameBoard = ['', '', '', '', '', '', '', '', ''];
    gameActive = true;  // Oyunu tekrar aktif yapıyoruz
    currentPlayer = 'X';  // İlk oyuncu 'X' olarak başlasın
    cells.forEach(cell => cell.textContent = '');  // Hücreleri temizle
    cells.forEach(cell => cell.classList.remove('x', 'o')); // X ve O renklerini temizle
    updateGameStatus(`Oyuna Başlayın`);  // Oyun durumu mesajını güncelle
    toggleDrawMessage(false);  // Beraberlik mesajını gizle
    startMessage.style.display = 'none';  // Başlangıç mesajını gizle
    scoreboard.style.display = 'block';  // Skor bölümünü göster
    board.style.display = 'flex';  // Oyun tahtasını göster
    endGameButton.style.display = 'inline-block';  // "Oyunu Bitir" butonunu göster
}

// Oyuna başla butonuna tıklama olayını dinle
startGameButton.addEventListener('click', function() {
    // Başlangıç mesajını ve butonu gizle
    startMessage.style.display = 'none';
    
    // Oyun tahtasını ve skoru göster
    board.style.display = 'flex';
    scoreboard.style.display = 'block';
    endGameButton.style.display = 'inline-block';  // "Oyunu Bitir" butonunu göster
    
    // Oyunu başlat
    gameActive = true;
    currentPlayer = 'X';
    updateGameStatus(`${currentPlayer}'in Sırası`);  // Başlangıç mesajı değişti
    updateScore();  // Başlangıçta skoru güncelle
});

// Hücrelere tıklama olayını dinle
cells.forEach(cell => cell.addEventListener('click', cellClick));

// "Oyunu Bitir" butonuna tıklama olayını dinle
endGameButton.addEventListener('click', function() {
    // Skorları sıfırla
    scoreX = 0;
    scoreO = 0;
    scoreDraw = 0; // Beraberlik skorunu sıfırlıyoruz
    updateScore();  // Skorları sıfırladık, güncelle

    resetGame();  // Oyunu sıfırlama fonksiyonunu çağır

    // Oyunu bitir butonuna basıldığında ana ekrana gönder
    startMessage.style.display = 'block';  // Başlangıç ekranı
    scoreboard.style.display = 'none';  // Skor bölümünü gizle
    board.style.display = 'none';  // Oyun tahtasını gizle
    endGameButton.style.display = 'none';  // "Oyunu Bitir" butonunu gizle
});
